package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Common {
	private static WebDriver driver;
	
	@Before
	public void setUp() throws Exception {
		System.out.println("Setup the driver");
		driver = new ChromeDriver();
	}
	
	@After
	public void tearDown() {
		driver.quit();
		System.out.println("Tear down");
	}
	
	public static WebDriver getDriver() {
		return driver;
	}
}