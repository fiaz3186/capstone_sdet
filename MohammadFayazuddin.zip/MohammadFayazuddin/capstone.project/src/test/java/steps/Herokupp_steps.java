package steps;

import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;

public class Herokupp_steps {

	WebDriver driver = Common.getDriver();

	@Given("I launch the application URL {string}")
	public void i_launch_the_application_url(String url) {
		driver.get(url);
	}

	@Then("The page title should be {string}")
	public void the_page_title_should_be(String expectedTitle) {
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle, "Page title does not match");
	}

	@When("I click on the {string} link")
	public void i_click_on_the_link(String linkText) {
		WebElement link = driver.findElement(By.linkText(linkText));
		link.click();
	}

	@Then("I should see the text {string}")
	public void i_should_see_the_text(String expectedText) {
		WebElement body = driver.findElement(By.tagName("body"));
		Assert.assertTrue(body.getText().contains(expectedText), "Expected text not found on page");
	}

	@When("I navigate back to the Home page")
	public void i_navigate_back_to_the_home_page() {
		driver.navigate().back();
	}

	@And("I select {string} from the dropdown")
	public void i_select_from_the_dropdown(String optionText) {
		Select dropdown = new Select(driver.findElement(By.id("dropdown")));
		dropdown.selectByVisibleText(optionText);
	}

	@Then("{string} should be selected in the dropdown")
	public void should_be_selected_in_the_dropdown(String expectedOption) {
		Select dropdown = new Select(driver.findElement(By.id("dropdown")));
		String selected = dropdown.getFirstSelectedOption().getText();
		Assert.assertEquals(selected, expectedOption, "Dropdown selection mismatch");
	}

	@Then("I should see the following hyperlinks on the Frames page:")
	public void i_should_see_the_following_hyperlinks_on_the_frames_page(io.cucumber.datatable.DataTable dataTable) {
		List<String> expectedLinks = dataTable.asList();
		for (String linkText : expectedLinks) {
			WebElement link = driver.findElement(By.linkText(linkText));
			Assert.assertTrue(link.isDisplayed(), "Link not found: " + linkText);
		}
	}
}